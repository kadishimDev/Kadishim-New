<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once 'config.php';

$data = json_decode(file_get_contents("php://input"), true);

// Basic validation
if (!isset($data['requester_name']) || !isset($data['deceased_name'])) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Missing required fields"]);
    exit;
}

// 1. Save to Database
$requestId = 0;
if ($pdo) {
    try {
        $stmt = $pdo->prepare("INSERT INTO kaddish_requests 
            (requester_name, requester_email, requester_phone, deceased_name, relationship, father_name, mother_name, gender, death_date_hebrew, death_date_gregorian, is_after_sunset) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->execute([
            $data['requester_name'],
            $data['requester_email'],
            $data['requester_phone'] ?? '',
            $data['deceased_name'],
            $data['relationship'] ?? '',
            $data['father_name'] ?? '',
            $data['mother_name'] ?? '',
            $data['gender'] ?? 'son_of',
            $data['death_date_hebrew'] ?? '',
            $data['death_date_gregorian'] ?? null,
            isset($data['is_after_sunset']) ? ($data['is_after_sunset'] ? 1 : 0) : 0
        ]);
        $requestId = $pdo->lastInsertId();
    } catch (Exception $e) {
        error_log("DB Error: " . $e->getMessage());
    }
}

// 2. Send Email
$to = 'request@kadishim.co.il';
$subject = "בקשת קדיש חדשה עבור: " . $data['deceased_name'];
$message = $data['html']; // Assumes HTML is passed from frontend

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: notification@kadishim.co.il" . "\r\n";

if (mail($to, $subject, $message, $headers)) {
    echo json_encode(["success" => true, "message" => "Request saved and email sent", "id" => $requestId]);
} else {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Failed to send email", "db_saved" => $requestId > 0]);
}
?>